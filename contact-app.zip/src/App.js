import React from "react";
import "./styles.css";
import Contact from "./components/Contact";

export default function App() {
  return (
    <div className="App">
      <Contact />
    </div>
  );
}
